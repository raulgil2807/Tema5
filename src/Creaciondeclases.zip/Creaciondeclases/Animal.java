package Creaciondeclases;

public class Animal {

    //Definir los atributos de la clase animal.
    private String raza, categoria, peso, altura;

    //Definimos los m�todos de animal
    public void dormir() {
        System.out.println("El elefante est� durmiendo");
    }

    public void comer() {
        System.out.println("El le�n est� comiendo carne");
    }

    protected void jugar() {
        System.out.println("El delf�n est� jugando con la pelota");
    }

}
