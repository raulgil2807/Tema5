package Creaciondeclases;

public class Pelicula {

    //Colocamos los atributos necesarios
    private String titulo, actor, genero, resolucion;
    private int edad;

    //Ahora vamos a definir los m�todos que a doptar pelicula.
    public void reproducir() {
        System.out.println("La reproduci�n de la pel�cula est� en curso");
    }

    public void verresolucion() {
        System.out.println("La resolucion de esta pelicula es UHD");
    }

    protected void encendervibracionasientos() {
        System.out.println("La vibraci�n de los asientos est� encendida");

    }

}
