package Creaciondeclases;

public class Main {

    public static void main(String[] args) {

        //DENTRO DEL MAIN VAMOS A CREAR UN OBJETO DE TIPO PERSONA
        Vehiculo toyota = new Vehiculo(); //Aqui he creado un objeto de tipo persona(toyota)
        Pelicula saw3 = new Pelicula();//Aqui he creado un objeto de tipo persona(saw3)
        Videojuego valorant = new Videojuego();//Aqui he creado un objeto de tipo persona(valorant)
        Animal elefante = new Animal();//Aqui he creado un objeto de tipo persona(telefante)

        //PARA LLAMAR A UN M�TODO SE HACE:
        //Llamamos a los m�todos de toyota
        toyota.acelerar();
        toyota.encenderluces();
        toyota.frenar();

        //Llamamos a los m�todos de saw3:
        saw3.encendervibracionasientos();
        saw3.verresolucion();
        saw3.reproducir();

        //Llamamos a los m�todos de valorant:
        valorant.nuevapartida();
        valorant.cargarpartida();
        valorant.puntuaciones();

        //Llamamos a los m�todos de elefante:
        elefante.comer();
        elefante.dormir();
        elefante.jugar();

    }

}
