package Creaciondeclases;

public class Videojuego {

    //Definimos los atributos de videojuego
    private String categoria, genero, nombre;
    private int clasificacionedad;

    //Definimos los m�todos de videojuego.
    protected void nuevapartida() {
        System.out.println("Quieres iniciar nueva partida?");
    }

    public void cargarpartida() {
        System.out.println("Cargar la partida que has guardado anteriormente");
    }

    public void puntuaciones() {
        System.out.println("Esta es la puntuacion de tu partida");
    }

}
