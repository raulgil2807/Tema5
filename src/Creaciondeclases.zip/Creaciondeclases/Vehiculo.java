package Creaciondeclases;

public class Vehiculo {

    //Definir los atributos de la clase vehiculo
    private String color, puertas, tipogasolina, marca;

    //Crear los m�todos que va a tener vehiculo
    protected void acelerar() {
        System.out.println("El coche acelera de 0-100 km/h en 3 segundos");
    }

    public void frenar() {
        System.out.println("La aceleraci�n del veh�culo es �ptima");
    }

    public void encenderluces() {
        System.out.println("Activado el sistema de luces del vehiculo");
    }
}
